# Please run proj3.m to run all of the parts of the project. I made separate files for some functions so that the main file would be nice and tidy.

Thanks,

-David