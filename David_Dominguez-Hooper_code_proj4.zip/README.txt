CS194-26 Project 4
David Dominguez Hooper
24828373

Run proj4.m to generate all images and videos (videos and images already provided in root directory for reference).

The project is divided into code section parts. 

Thanks for grading! I had a lot of fun on this project!!! :)